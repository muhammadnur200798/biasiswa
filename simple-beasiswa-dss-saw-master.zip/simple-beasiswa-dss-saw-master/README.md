## Sistem Pendukung Keputusan Penerimaan Beasiswa (SAW) sederhana

### Cara menjalankan
1. Clone repository dengan perintah
```
git clone https://github.com/imamdigmi/simple-dss-beasiswa-saw.git
```
2. Letakkan directory `simple-dss-beasiswa-saw` di dalam root directory web server
3. Import database.sql
4. Ubah Username dan Password pada file config.php
5. Lalu browse ke ``localhost/simple-dss-beasiswa-saw`` di browser

### Kode Warna
1. Merah      = danger
2. Kuning     = yellow
3. Hijau      = success
4. Biru       = primary
5. Putih      = default
6. Biru Muda  = info
