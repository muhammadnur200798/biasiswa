<body bgcolor="Pink">
<h1><p align="center">
<font color="maroon">
   	Selamat Datang di Sistem Pendukung Keputusan <br>
	Penentuan Penerima Beasiswa di STMIK AKAKOM Yogyakarta <br>
	Menggunakan Metode Simple Additive Weighting (SAW)
</h1> 
</b>
</p>
</font>